#include <stdio.h>
#include <stdlib.h>

//Mencetak sisi-sisi tree yang direpresentasikan kode Prufer

int main()
{
    int prufer[] = {3, 1, 4, 2};
    int n = sizeof(prufer) / sizeof(prufer[0]);
    printTreeEdges(prufer, n);
    return 0;
}